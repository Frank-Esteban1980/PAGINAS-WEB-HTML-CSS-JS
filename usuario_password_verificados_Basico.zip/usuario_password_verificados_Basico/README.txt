USUARIO Y CONTRASEÑA VERIFICADOS

NO se han utilizado expresiones regulares para las verificaciones.
El usuario y contraseña se validan si están escritos; y las contraseñas si coinciden.

HTML

	Está vinculado al css y al js.
	Body con función js que cargará dejando el cursor en el nombre.
	Formulario con inputs que piden el usuario contraseña y verificar contraseña.
	El formulario contien la función mediante un onsubmit que ejecuta 
	la función cuando el botón se pulsa.
	Inputs: Nombre, apellidos, DNI tipo texto con id para luego llamar al DOM desde js y aplicar css. También un span con id para controlar los errores.
	Después del fieldset tenemos el botón de envío.

CSS
	Básico aplica a todo un margin, padding y una fuente.
	Fieldset tiene un color de fondo, padding, margin. Está en una caja con sombra en tres lados color gris. Ancho al 50vw;
	Una clase error para aplicar cuando el usuario no complete o ponga datos erróneos.


		
JS
	Primero captura los elementos del DOM por el ID.
	La función f_cargar será la primera que cargue en el body y lleve el cursor o foco a la casilla usuario.
	En la función de validación de elementos guardamos en unas variables el valor de cada elemento con .value.
	Tendremos una variable controlador que se genera con TRUE, var ok=true.
	Para este ejercicio NO se usan expresiones regulares para validar los datos. Se aplican condiciones básicas dentro de los if - else if.
	El usuario se validan primero verificando si están vacías, se aplica el error del css y el mensaje de obligación de ponerlos; después se verifica si cumple con la longitud.
	Las contraseñas se verifican que se escriban y luego que coincidan.
	La verificación final se basará en que el controlador ok sea igual a true lanzando un mensaje al estar correcto o aplicando el css error y pidiendo revisar los datos poniendo el foco en el campo erróneo.

