
/*Acceder a los elementos del DOM mediante id*/

var elemento_usuario = document.getElementById("usuario");
var elemento_clave1_usuario = document.getElementById("clave1_usuario");
var elemento_clave2_usuario = document.getElementById("clave2_usuario"); 


//Elementos de error del DOM

var elemento_error_usuario = document.getElementById("error_usuario");
var elemento_error_clave1_usuario = document.getElementById("error_clave1_usuario");
var elemento_error_clave2_usuario = document.getElementById("error_clave2_usuario");


/* Cargar la página cuando entramos al body*/

var f_cargar = function()
{
    elemento_nombre_usuario.focus();
};


var f_validar = function()
{
    var ok = true;

    /*Llamamos a cada variable que vamos a validar y buscamos el valor de cada uno de los campos
    del formulario con VALUE*/

    var usuario = elemento_usuario.value;
    var clave1_usuario = elemento_clave1_usuario.value;
    var clave2_usuario = elemento_clave2_usuario.value;

    if(usuario.trim()=="")
    {
        elemento_error_usuario.innerText = "Campo USUARIO es obligatorio";
        elemento_usuario.classList.add("error");
        
        ok=false;
    }
    else if(usuario.trim().length>=10)
    {
        elemento_error_usuario.innerText = "Campo USUARIO no puede superar 10 dígitos";
        elemento_usuario.classList.add("error");
        
        ok=false;
    }

    if (clave1_usuario === "")
    {
        /* Con un IF se comprueban se ha escrito o no la contraseña. Es obligatoria*/
        elemento_error_clave1_usuario.innerText = "La contraseña es obligatoria.";
        elemento_error_clave1_usuario.classList.add("error");
        elemento_error_clave1_usuario.focus();
        ok =false;
    }
    else if(clave2_usuario === "")
    {
        /* Con un IF se comprueban se ha escrito o no la contraseña. Es obligatoria*/
        elemento_error_clave2_usuario.innerText = "La contraseña es obligatoria.";
        elemento_error_clave2_usuario.classList.add("error");
        elemento_error_clave2_usuario.focus();
        ok =false;
    }
    else if(clave1_usuario != clave2_usuario)
    /* Con un IF se comprueban si no son iguales, se informa y devolvermos el foco para que
            se escriba nuevamente la contraseña en clave1*/
    {
        elemento_error_clave2_usuario.innerText = "Las contraseñas no coinciden.";
        elemento_error_clave2_usuario.classList.add("error");
        elemento_error_clave1_usuario.focus();
        ok = false;
    } 
    

    /* Para ok true, saltará el mensaje de ok.
    Para ok false, se pide revisar los datos, y el foco va a la casilla con clase error, 
    creando una variable error y llamando a getElementaryByClassName (error) recoge un
    array con todos los errores.
    Se da el foco al primer error del array*/

    if ( ok == true)
    {
        alert("Datos enviados correctamente.");
    }
    else
    {
        alert("Revisar campos.");
        var campo_erroneo =document.getElementsByClassName("error");
        campo_erroneo[0].focus();
    }

    return ok;
};