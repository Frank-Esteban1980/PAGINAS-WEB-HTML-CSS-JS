/*Variables de datos personales del DOM*/

var elemento_nombre_usuario = document.getElementById("nombre_usuario");
var elemento_apell_usuario = document.getElementById("apell_usuario");
var elemento_dni = document.getElementById("dni");
//Elementos de error del DOM
var elemento_error_nombre_usuario = document.getElementById("error_nom_usuario");
var elemento_error_apell_usuario = document.getElementById("error_apell_usuario");
var elemento_error_dni = document.getElementById("error_dni");

var f_cargar = function()
{
    elemento_nombre_usuario.focus();
};


var f_validar = function()
{
    var ok = true;

    /*Llamamos a cada variable que vamos a validar y buscamos el valor de cada uno de los campos
    del formulario con VALUE*/

    var nombre_usuario = elemento_nombre_usuario.value;
    var apell_usuario = elemento_apell_usuario.value;
    var dni = elemento_dni.value;


/* Comprobar si está vació el campo y se ejecuta la obligación de nombre,
cambia de color si es error,
mantiene el foco si es error, aunque si son dos o tres errores.
Y para cada uno de los campos*/


    if(nombre_usuario.trim()=="")
    {
        elemento_error_nombre_usuario.innerText = "Campo NOMBRE es obligatorio";
        elemento_nombre_usuario.classList.add("error");
        elemento_nombre_usuario.focus();
        ok=false;
    }
    else if(nombre_usuario.trim().length>=15)
    {
        elemento_error_nombre_usuario.innerText = "Campo NOMBRE no puede superar 15 letras";
        elemento_nombre_usuario.classList.add("error");
        elemento_nombre_usuario.focus();
        ok=false;
    }


    if(apell_usuario.trim()=="")
    {
        elemento_error_apell_usuario.innerText = "Campo APELLIDO es obligatorio";
        elemento_apell_usuario.classList.add("error");
        
        ok=false;
    }
    else if(apell_usuario.trim().length>=30)
    {
        elemento_error_apell_usuario.innerText = "Campo APELLIDOS no puede superar 30 letras";
        elemento_apell_usuario.classList.add("error");
        
        ok=false;
    }


    if(dni.trim()=="")
    {
        elemento_error_dni.innerText = "Campo DNI es obligatorio";
        elemento_dni.classList.add("error");
        
        ok=false;
    }
    else if(dni.trim().length>9)
    {
        elemento_error_dni.innerText = "Campo DNI no puede superar 9 dígitos";
        elemento_dni.classList.add("error");
        
        ok=false;
    }


    if ( ok === true)
    {
        alert("Datos enviados correctamente.");
    }
    else
    {
        alert("Revisar campos.");
        var campo_erroneo =document.getElementsByClassName("error");
        campo_erroneo[0].focus();
    }

    return ok;
};

