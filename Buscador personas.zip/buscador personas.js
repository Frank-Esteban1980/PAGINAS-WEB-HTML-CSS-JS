/* json se usa en aplicaciones web y movil, bbdd. 
Los datos de las personas estarán en json y podrán venid de orígenes externos y 
mantiene la lógica del código*/

/*Creamos un array que contendrá los usuarios.
Estos datos nos pueden estar siendo cargados de otro origen como una bbdd.
*/

var users = [
    {
        name:'Lucy',
        genero: 'Femenino',
        hobby: 'mascotas',
        avatar: 'lucy.jpg'
    },
    {
        name:'Bety',
        genero: 'Femenino',
        hobby: 'viajes',
        avatar: 'bety.jpg'
    },
    {
        name:'Rolando',
        genero: 'Masculino',
        hobby: 'musica',
        avatar: 'rolando.jpg'
    },
    {
        name:'Cris',
        genero: 'Masculino',
        hobby: 'mascotas',
        avatar: 'cris.jpg'
    },
    {
        name:'Paul',
        genero: 'Masculino',
        hobby: 'viajes',
        avatar: 'paul.jpg'
    },
   
];



/*Evento para saber que la página está cargada.
Con addEventListener se escucha un evento, se forma de parámetros:
 ('evento', funcion que ejectua alto)*/

window.addEventListener('load', function(){
    this.alert("Elegir Masculino, Femenino");
    this.alert("Hobby viajes, mascotas, musica");

    

    /*Seleccionar un evento por el identificador que tiene el DOM, en este caso un botón*/

    /* var dom_boton = document.getElementById('buscar');
    buscar.addEventListener('click', function(){
        alert('--> Buscar amigos <--');
    }); */
 

    function search(){
        //resultados.innerHTML = 'Hola <br/>CAMBIADO TODO <div stile="backgroundcolor:yellow;>';

        /*Accedemos al elemento hobby y en otra varible guardamos el valor de hobby, 
        emitir mensaje que diga que se el hobby indicado*/
    var dom_hobby = document.getElementById('hobby');
    var hobby = dom_hobby.value;
    alert("Buscando como hobby: "+hobby);

        /*Acceder  genero que son varios y están en un array por ser un SELECT OPTION,
         por lo que hay que entrar en el array y buscar el elemento que se ha seleccionado 
        y en otra variable guardar el valor, para dar un mensaje*/
    
    var dom_genero = document.getElementById('genero');
    var seleccionado = dom_genero.selectedIndex;
    var genero = dom_genero.options[seleccionado].value;
    alert("Buscando genero: "+genero);


    /*Buscaremos cada uno de los usuarios según el largo del array de usuarios*/
    var resultadosHTML='';
    var numUsuarios = users.length;

    /*  Con este for se itera sobre el array y muestra el nombre de cada elemento de user:
    
    for(var i=0; i<numUsuarios; i++){
        resultadosHTML = resultadosHTML + ' ' + users[i].name; */

/*con un for se itera en cada usuario y cada elemento para que en el HTML
 se pueda ver*/

        for(var i=0; i<numUsuarios; i++){


            if(genero==='Todos'  || genero==users[i].genero){

                if(hobby=='' || hobby == users[i].hobby){

                

                /* Si cumple lo anterior muestra:
                En el resultado de cada iteración muestra un HTML recorriendo las imágnes de cada elemento
                del array, el nombre de cada elemento y el hobby*/
                resultadosHTML += '<div class="person-row">\
                                <img src="./fotos/'+users[i].avatar+'" />\
                                <div class="person-info">\
                                <div>'+users[i].name+'</div>\
                                <div>'+users[i].hobby+' </div></div>\
                                <button>Añadir amigo</button></div>';
                }
           }                   
        }
        resultados.innerHTML = resultadosHTML;
    };


        
    
    /*Se puede modificar el contenido del DOM accediendo a el y dándole otro contenido o estilo*/
    var resultados = document.getElementById('resultados');
    var dom_boton = document.getElementById('buscar');

    /*llamar a la función al hacer clic en el botón buscar*/
    buscar.addEventListener('click', search);
    
});