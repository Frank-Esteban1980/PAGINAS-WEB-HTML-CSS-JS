/*Variables de datos personales y de conexión*/

var elemento_nombre_usuario = document.getElementById("nombre_usuario");
var elemento_apell_usuario = document.getElementById("apell_usuario");
var elemento_dni = document.getElementById("dni");

var elemento_usuario = document.getElementById("usuario");
var elemento_clave1_usuario = document.getElementById("clave1_usuario");
var elemento_clave2_usuario = document.getElementById("clave2_usuario"); 


//Elementos de error
var elemento_error_nombre_usuario = document.getElementById("error_nom_usuario");
var elemento_error_apell_usuario = document.getElementById("error_apell_usuario");
var elemento_error_dni = document.getElementById("error_dni");
var elemento_error_usuario = document.getElementById("error_usuario");
var elemento_error_clave1_usuario = document.getElementById("error_clave1_usuario");
var elemento_error_clave2_usuario = document.getElementById("error_clave2_usuario");


var f_cargar = function()
{
    elemento_nombre_usuario.focus();
};





var f_comprobarContrasena = function()
{/*Guardamos el valor de las claves de cada usuario en otra variable para luego validarlas*/
    var clave1_usuario = elemento_clave1_usuario.value;
    var clave2_usuario = elemento_clave2_usuario.value;

    /*Comprobar si la clave1 está vacía, si es true no continua*/
    if (clave1_usuario != ""){
/* Con un IF se comprueban si no son iguales, se informa y devolvermos el foco para que
    se escriba nuevamente la contraseña en clave1*/
        if(clave1_usuario == clave2_usuario)
        {
            elemento_error_clave1_usuario.innerText = "Contraseñas coinciden.";
            
        }
        else
        {
            elemento_error_clave1_usuario.innerText = "Las contraseñas no coinciden.";
            elemento_error_clave1_usuario.focus();
        }
    }
};




var f_validar = function()
{
    var ok = true;

    /*Llamamos a cada variable que vamos a validar y buscamos el valor de cada uno de los campos
    del formulario con VALUE*/

    var nombre_usuario = elemento_nombre_usuario.value;
    var apell_usuario = elemento_apell_usuario.value;
    var dni = elemento_dni.value;
    var usuario = elemento_usuario.value;
    var clave1_usuario = elemento_clave1_usuario.value;
    var clave2_usuario = elemento_clave2_usuario.value;

/* Comprobar si está vació el campo y se ejecuta la obligación de nombre,
cambia de color si es error,
mantiene el foco si es error, aunque si son dos o tres errores.
Y para cada uno de los campos*/

    if(nombre_usuario.trim()=="")
    {
        elemento_error_nombre_usuario.innerText = "Campo NOMBRE es obligatorio";
        elemento_error_nombre_usuario.classList.add("error");
        elemento_nombre_usuario.focus();
        ok=false;
    }
    else if(nombre_usuario.trim().length>=15)
    {
        elemento_error_nombre_usuario.innerText = "Campo NOMBRE no puede superar 15 letras";
        elemento_error_nombre_usuario.classList.add("error");
        elemento_nombre_usuario.focus();
        ok=false;
    }



    if(apell_usuario.trim()=="")
    {
        elemento_error_apell_usuario.innerText = "APELLIDO es obligatorio";
        elemento_error_apell_usuario.classList.add("error");
        
        ok=false;
    }
    else if(apell_usuario.trim().length>=30)
    {
        elemento_error_apell_usuario.innerText = "APELLIDOS no puede superar 30 letras";
        elemento_error_apell_usuario.classList.add("error");
        
        ok=false;
    }

   
    if(dni.trim()=="")
    {
        elemento_error_dni.innerText = "DNI es obligatorio";
        elemento_error_dni.classList.add("error");
        
        ok=false;
    }
    else if(dni.trim().length>9)
    {
        elemento_error_dni.innerText = "DNI no puede superar 9 dígitos";
        elemento_dnerror_dni.classList.add("error");
        
        ok=false;
    }


    if(usuario.trim()=="")
    {
        elemento_error_usuario.innerText = "USUARIO es obligatorio";
        elemento_error_usuario.classList.add("error");
        elemento_usuario.focus();
        
        ok=false;
    }
    else if(usuario.trim().length>=10)
    {
        elemento_error_usuario.innerText = "USUARIO no puede superar 10 dígitos";
        elemento_error_usuario.classList.add("error");
        
        ok=false;
    }

    if (clave1_usuario === "")
    {
        /* Con un IF se comprueban se ha escrito o no la contraseña. Es obligatoria*/
        elemento_error_clave1_usuario.innerText = "Contraseña es obligatoria.";
        elemento_error_clave1_usuario.classList.add("error");
        elemento_error_clave1_usuario.focus();
        ok =false;
    }
    else if(clave2_usuario === "")
    {
        /* Con un IF se comprueban se ha escrito o no la contraseña. Es obligatoria*/
        elemento_error_clave2_usuario.innerText = "Contraseña es obligatoria.";
        elemento_error_clave2_usuario.classList.add("error");
        elemento_error_clave2_usuario.focus();
        ok =false;
    }
    else if(clave1_usuario != clave2_usuario)
    /* Con un IF se comprueban si no son iguales, se informa y devolvermos el foco para que
            se escriba nuevamente la contraseña en clave1*/
    {
        elemento_error_clave2_usuario.innerText = "Contraseñas no coinciden.";
        elemento_error_clave2_usuario.classList.add("error");
        elemento_error_clave2_usuario.focus();
        ok = false;
    } 

    /* Para ok true, saltará el mensaje de ok.
    Para ok false, se pide revisar los datos, y el foco va a la casilla con clase error, 
    creando una variable error y llamando a getElementaryByClassName (error) recoge un
    array con todos los errores.
    Se da el foco al primer error del array*/

    if ( ok == true)
    {
        alert("Datos enviados correctamente.");
    }
    else
    {
        alert("Revisar campos.");
        var campo_erroneo =document.getElementsByClassName("error");
        campo_erroneo[0].focus();
    }

    return ok;
};