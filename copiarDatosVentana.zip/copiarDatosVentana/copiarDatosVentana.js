/* Conseguir que cada valor del formulario se guarde en una variable por cada elemento del formulario*/

var elemento_nombre = document.getElementById("nombre");
var elemento_DNI = document.getElementById("DNI");
var elemento_telefono = document.getElementById("telefono");




/* Copiar datos ejecuta la función que copia los datos que se ponen en el formulario
          los guarda en una variable para luego sacarlos en otra ventana. */

var f_copiarDatos = function copiarDatos()
{
var nombre = elemento_nombre.value;
var DNI = elemento_DNI.value;
var telefono = elemento_telefono.value;

/*Mensaje que se verá en la ventana, Muestra el mensaje con los datos introducidos en el formulario.
tiene color azul las letras.
y tenemos un botón que al pulsar cierra la ventana emergente. */

var mensaje = `<div style = "color:blue;" >`
                    +`NOMBRE:  ${nombre} <br>` 
                    + `DNI: ${DNI} <br>` 
                    + `TELEFONO: ${telefono} <br>` 
                    +`</div>`

                    /* Ademas incluimos un BOTON CERRAR que tiene la funcion método close()*/
                    + `<br> <button onclick="window.close()"> Cerrar </button>`;


/*Objeto WINDOW Crear nueva ventana y el método OPEN abre la ventana que será la que contenta el mensaje */
var ventana = window.open("nuevaVentana", "_blank", "toolbar=yes, resizable=yes, top=250, left=150, width=500, height=200");

/*el método write escríbe sobre el objeto documento*/
ventana.document.write(mensaje);
};