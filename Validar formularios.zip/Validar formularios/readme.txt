VALIDACIÓN DE DATOS DE UN FORMULARIO CON EXPRESIONES REGULARES

HTML

El formulario contiene la función que validará y cargará la validación cuando se pulse el botón con onsubmit.
Se divide en dos fieldset por un lado de los datos personales y el de los datos académicos.
En la legend de Datos personales están los inputs de nombre, apellido y edad de tipo texto como obligatorios con (*) que no tiene efectos sobre el usuario, se convertirá en obligatoria con la función de js.
Los span contienen el id de los errores para que el js pueda después aplicar el css y js.
El género es de type radio contenido en un div interno 
El input DNI contendrá la función de validación de js.
La fecha de nacimiento y el email tipo text se validarán con la función js del botón.
Los datos académicos tienen forma de select option se validará que seleccione un curso obligatoriamente.
Para el idioma es un checkbox que se validará si está checked al menos uno por defecto está español, no debería dar error salvo que se desactive por el usuario y no se seleccione otro.
Hay dos botones uno para enviar que activa la ejecución de la validación de todos los campos en js con el onsubmit del formulario.
El segundo botón tiene la función borrar que borra todo recargando la página con un reload.

CSS

Body con un fondo, fuente y tamaño de fuente.
FORM con un fondo y sombra
WIDTH en porcentaje, display auto, márgenes alto izquierdo y derecho.
span con un tipo de letra para ver los errores
Botones en estado normal y otro para le hover.
La clase error para que se aplique cuando el js lo indique si las validacionose ok = false.


JAVASCRIPT

Accedemos a cada elemento del DOM con el id con document.getElementById("dni") por ejemplo.
En la función tenemos una variabla OK = true como controlador que las validaciones, es decir si todas son true, ok será true, si una es falso ok = false.
Capturamos el valor de cada elemento.
Creamos las espresiones regulares por las que se va a comparar el resultado de cada elemento del DOM para tener un ok true o false en cada caso.
Para nombre, apellidos, DNI, edad, f nacimiento, email y curso primero se valida si está vacío el valor. 
Para nombres apellidos edad dni email, fnacimiento se valida con la expresión regular por ejemplo reg_nombre.text(nombre)==false.
Si está vacío o no cumple la expresión regular se activa la clase css y salta el aviso de error en cada span. ok pasa a false.
si esta relleno y cumple la expresión regular se desactiva la clase css y ok queda en true.
RADIO se comprueba si uno u otro está checked: if(dom_hombre.checked == false && dom_mujer.checked == false). Saltará el error y la clase css si es false. sino se no aplica la calse y no hay mensaje.
CHECKBOX del idioma se verifica que uno esté checed-

Finalmente si ok consigue el valor true con todas las comprobaciones, se envían los datos, sino se aplica css error con el foco en el elemento que no cumple.


