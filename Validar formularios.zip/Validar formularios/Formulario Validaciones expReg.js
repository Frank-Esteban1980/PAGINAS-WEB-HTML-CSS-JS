/* Las variables guardan leen los elementos del DOM y el valor deL ELEMENTO en entrando al documento con el método
getElementById("caja"). */

/* Asi se consigue manipular, comprobar o verificar el valor de la ELEMENTO*/
/*Crear tantas variables como cajas tengamos que validar*/

var dom_nombre = document.getElementById("nombre");
var dom_apellido1 = document.getElementById("apellido1");
var dom_apellido2 = document.getElementById("apellido2");
var dom_edad = document.getElementById("edad");

var dom_hombre = document.getElementById("hombre");
var dom_mujer = document.getElementById("mujer");
var dom_lblGenero = document.getElementById("lblGenero");
var dom_lblcurso = document.getElementById("lblcurso");
var dom_lblidioma = document.getElementById("lblidioma")

var dom_dni = document.getElementById("dni");
var dom_fnacimiento = document.getElementById("fnacimiento");
var dom_correo = document.getElementById("correo");
var dom_curso = document.getElementById("curso");
var dom_ingles = document.getElementById("ingles");
var dom_espanol = document.getElementById("espanol");
var dom_frances = document.getElementById("frances");
var dom_aleman = document.getElementById("aleman");


var dom_errorNombre = document.getElementById("errorNombre");
var dom_errorApellido1 = document.getElementById("errorApellido1");
var dom_errorApellido2 = document.getElementById("errorApellido2");
var dom_errorEdad = document.getElementById("errorEdad");
var dom_errorGenero = document.getElementById("errorGenero");
var dom_errordni = document.getElementById("errordni");
var dom_errorFnacimiento = document.getElementById("errorFnacimiento");
var dom_errorCorreo = document.getElementById("errorCorreo");
var dom_errorCurso = document.getElementById("errorCurso");
var dom_errorIdioma = document.getElementById("errorIdioma");


var f_validar = function()
{
    // Declarar las variables:

    //valor devuleto por la función con datos correctas

    var ok = true;

    //Valor cada campo. Llama a cada variable y le pide el valor.
    var nombre = dom_nombre.value;
    var apellido1 = dom_apellido1.value;
    var apellido2 = dom_apellido2.value;
    var edad = dom_edad.value;
    var dni = dom_dni.value;
    var fnacimiento = dom_fnacimiento.value;
    var correo = dom_correo.value;
    var curso = dom_curso.value;
    var ingles = dom_ingles.value;


    /* Expresiones regulares. las creamos porque luego serán con las que va a validar
    cada uno de los valores que contienen las cajas*/

    var reg_nombre = /^[a-zA-ZñÑçÇ ]{2,20}$/; //Espresión regular para validar 20 caraccteres alfabéticos del nombre
    var reg_apellidos = /^[a-zA-ZñÑçÇ]{3,40}$/;//Expresión regular para validar 40 caracteres alfabéticos de los dos apellidos
    var reg_edad = /^[0-9]$/; //Edad serán números a elegir de 0 a 9 y se pueden combinar
    var reg_dni = /^[0-9]{8}[a-zA-Z]{1}$/; //se pide que sean 8 número y 1 letra. Estos serán validados por otra función adicional
    var reg_correo = /@{1}/; ///^[\w]+@{1}[\w]+\.[a-z]{2,3}$/; Aplicamos un método sencillo
    var reg_fnacimiento = /^[0-9]{2}\/[0-9]{2}\/[0-9]{4}$/; //será formato de números de 0 a 9 en grupos de 2, 2 y 4 (dd/mm/aaaa)


    // Validaciones. Validar cada uno de los campos

            /* 1. Función que valide el campo NOMBRE que tendrá que tener 20 caaracteres y solo caracteres alfabéticos:
        - No puede estar vacío
        - Si tiene números o especiales etc, avisar y poner el fonco en Nomre
        - Si supera 20 caracteres avisar y poner el foco en Nombre
        * Hay que unirla a form con el evento onsumit*/

        /*comparamos el valor que está en la caja NOMBRE, nombre.value; está vaciá*/
    if(nombre.trim()=="")
    {
        /*Para poner en rojo el borde y las letras del aviso del error,
        crera un css con el formatod que queremos.
        Luego llamamos con el valor.classList.add("atributocss")
        /*Si está vacío salta como error:
        Avisa al usuario el motivo del error. 
        Para imprimir el error en etiquetas dobles se usa el id de la etiqueta
        y el método innerText con el texto que queremos*/
        dom_nombre.classList.add("error");
        /*Si está vacío salta como error:
        Avisa al usuario el motivo del error. 
        Para imprimir el error en etiquetas dobles se usa el id de la etiqueta
        y el método innerText con el texto que queremos*/
        dom_errorNombre.innerText = "El nombre es obligatorio";
        ok=false; //dejar la valiable ok falso para indicar que el formulario da error y no viaja
    }
    /*con test se valida si el valor de nombre (que fue capturada desde la var dom_nombre)
     cumple con la expresión regular que debe cumplir.
    if(exp_regular.test(idatributo))*/
    else if(reg_nombre.test(nombre)==false)
    {
        dom_nombre.classList.add("error");
        dom_errorNombre.innerText = "El nombre debe contener entre 2 y 20 letras";
        ok=false;
    }
    else
    {
        /* Si se ha validado todo, hay que dejar sin aplicar el css "error" y
        el mensaje de error no aparecerá*/
        dom_nombre.classList.remove("error");
        dom_errorNombre.innerText = "";
    }

  /*  Validar el valor de la caja PRIMER APELLIDO */

    //Revisar si el cambio tiene algo


    if(apellido1.trim()=="")
    {
        dom_apellido1.classList.add("error");
        dom_errorApellido1.innerText = "El primer apellido es obligatorio";
        ok=false; //dejar la valiable ok falso para indicar que el formulario da error y no viaja
    }
    else if(reg_apellidos.test(apellido1)==false)
    {
        dom_apellido1.classList.add("error");
        dom_errorApellido1.innerText = "El primer apellido debe contener entre 2 y 40 letras";
        ok=false;
    }
    else
    {
        /* Si se ha validado todo, hay que dejar sin aplicar el css "error" y
        el mensaje de error no aparecerá*/
        dom_apellido1.classList.remove("error");
        dom_errorApellido1.innerText = "";
    }

/*  Validar el valor de la caja SEGUNDO APELLIDO */

    if(apellido2.trim()=="")
    {
        dom_apellido2.classList.add("error");
        dom_errorApellido2.innerText = "El segundo apellido es obligatorio";
        ok=false; //dejar la valiable ok falso para indicar que el formulario da error y no viaja
    }
    else if(reg_apellidos.test(apellido2)==false)
    {
        dom_apellido2.classList.add("error");
        dom_errorApellido2.innerText = "El segundo apellido debe contener entre 2 y 40 letras";
        ok=false;
    }
    else
    {
        /* Si se ha validado todo, hay que dejar sin aplicar el css "error" y
        el mensaje de error no aparecerá*/
        dom_apellido2.classList.remove("error");
        dom_errorApellido2.innerText = "";
    }

    /* Validar EDAD*/

    if(edad.trim()=="")
    {
        dom_edad.classList.add("error");
        dom_errorEdad.innerText = "La edad es obligatorio";
        ok=false; 
    }
    /*validamos que:
    - No es número o,
    - si es numero y está debajo de 0 o supera 99 
    en estos casos no se cumple lo que buscamos*/
    else if(isNaN(edad))
    {
        dom_edad.classList.add("error");
        dom_errorEdad.innerText = "La edad debe ser números entre 0 y 99 años";
        ok=false;
    }
    else if((isNaN(edad)==false && edad <0 || edad>99))
    {
        dom_errorEdad.classList.add("error");
        dom_errorEdad.innerText = "La edad debe ser entre 0 y 99 años";
        ok=false;
    }
    else
    {
        /* Si se ha validado todo, hay que dejar sin aplicar el css "error" y
        el mensaje de error no aparecerá*/
        dom_errorEdad.classList.remove("error");
        dom_errorEdad.innerText = "";
    }

// Validar RADIO GENERO

    if(dom_hombre.checked == false && dom_mujer.checked == false)
    {
        dom_lblGenero.classList.add("error");
        dom_errorGenero.innerText = "Seleccione hombre o mujer";
        ok=false;
    }
    else
    {
        dom_lblGenero.classList.remove("error");
        dom_errorGenero.innerText = ""; 
    }


//VALIDAR  DNI
    if(dni.trim() =="")
    {
        dom_errordni.innerText = "El DNI es obligatrio"
        dom_dni.classList.add("error");
        ok=false;
    }
    else if(reg_dni.test(dni)==false)
    {
        dom_errordni.innerText = "DNI incorrecto";
        dom_dni.classList.add("error");
        ok=false;
    }
    else if(f_validarDNI(dni)==false)
    {
        dom_errordni.innerText = "DNI incorrecto revise su documento.";
        dom_dni.classList.add("error");
        ok=false;
    }
    else
    {
        dom_errordni.innerText = "";
        dom_dni.classList.remove("error");
    }

    

//VALIDAR  FECHA NACIMIENTO

    if(reg_fnacimiento.test(fnacimiento)==false)
    {
        dom_errorFnacimiento.innerText = "Fecha nacimiento incorrecta dd/mm/aaaa";
        dom_fnacimiento.classList.add("error");
        ok=false;
    }
    else
    {
        dom_errorFnacimiento.innerText = "";
        dom_fnacimiento.classList.remove("error");
    }


    if(correo.trim() =="")
    {
        dom_errorCorreo.innerText = "El correo es obligatrio";
        dom_correo.classList.add("error");
        ok=false;
    }
    else if(reg_correo.test(correo)==false)
    {
        dom_errorCorreo.innerText = "Correo incorrecto";
        dom_correo.classList.add("error");
        ok=false;
    }
    else
    {
        dom_errorCorreo.innerText = "";
        dom_correo.classList.remove("error");
    }


    //CHECK CURSO  crea un error

    if (curso == "")
    {
        dom_errorCurso.innerText = "Seleccionar el curso.";
        dom_lblcurso.classList.add("error");
        ok=false;
    }
    else
    {
        dom_errorCurso.innerText = "";
        dom_lblcurso.classList.remove("error");
    }

// VERIFICAR IDIOMAS, se verifica que siempre se marque al menos español.
/* hay que acceder a la caja para verificar si está marcado o no.
Al tener marcado por defecto español, no saltaría, pero si el usuario lo quita, 
se le informa que este es obligatorio.
*/
    if (dom_espanol.checked == false)
    {
        dom_lblidioma.classList.add("error");
        dom_errorIdioma.innerText = "Obligatorio conocer idioma español";
    }
    else{
        dom_lblidioma.classList.remove("error");
        dom_errorIdioma.innerText = "";

    }
        
    /* Vamos a avisar al usuario que el formulario se envió correctamente.
    OK se valida como TRUE y saltará una ventana de aviso.
    si no es OK TRUE busca el elemento erroneo y pone el foco en ese elemento para cambiarlo*/


    if (ok==true)
    {
        alert("Datos formulario enviados correctamente.")
    }
    else
    {
        /* Si no es OK, buscamos todos las cajas que tienen la clase "error",
        esto crea un array con todos los elementos que contienen la clase error y 
        lo ponermos el foco en el primer elemento que encuentre*/
        document.getElementsByClassName("error")[0].focus();

    }

    return ok;
};





/* La función de cálculo del DNI revisa si el DNI es correcto en sus números y letras
y lanzará un respuesta.
esa respuesta es llamada por la FUNCIÓN que valida el DNI.
si está validado OK en la funcición principal se acepta el OK */
var f_validarDNI = function(p_dni){
    var cadenaLetras = "TRWAGMYFPDXBNJZSQVHLCKE";
    var numero = p_dni.substring(0,8);
    var letrasUsuario = p_dni.substring(8,9);
    var letraCorrecta = cadenaLetras.charAt(numero%23);
    var respuesta;

    if(letrasUsuario == letraCorrecta)
    {
        respuesta = true;
    }
    else
    {
        respuesta = false;
        errordni.innerText = "DNI erroneo."
        errordni.classList.add("error");
    }

    return respuesta;
};

/*la vuncion borrar va unida al botón borrar,
lo que hará es recargar la página borrando todos los elementos escritos.*/

var f_borrar = function()
{
    window.location.reload()
};